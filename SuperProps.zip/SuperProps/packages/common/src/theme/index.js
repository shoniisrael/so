import { appTheme } from './app';
import { agencyTheme } from './agency';

export const theme = {
  appTheme,
  agencyTheme,
};
